import "../../index.css"; // Import the CSS file for NotFound


export default function NotFound() {
  return (
    <>
      
      <div className="not-found-container">
        <p className="not-found-message">The Page or Resource You are Looking For Is Not Found</p>
        <p className="not-found-try">Please Try Again</p>
      </div>
    </>
  );
};
