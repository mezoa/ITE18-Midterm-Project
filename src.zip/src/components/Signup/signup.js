import React, { useState } from 'react';
import { Col, Button, FormGroup, Input, Row } from 'reactstrap';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Link, useNavigate } from 'react-router-dom';
import { storeUser } from '../../helper';

const initialUser = { name: '', email: '', password: '' };

const SignUp = () => {
  const [user, setUser] = useState(initialUser);
  const navigate = useNavigate();

  const handleChange = ({ target }) => {
    const { name, value } = target;
    setUser((currentUser) => ({
      ...currentUser,
      [name]: value,
    }));
  };

  const handleSignUp = async () => {
    const url = 'http://localhost:1337/api/auth/local/register';
    try {
      if (user.name && user.email && user.password) {
        const { data } = await axios.post(url, {
          username: user.name,
          email: user.email,
          password: user.password
        });
        if (data.jwt) {
          storeUser(data);
          toast.success('Signed up successfully!', {
            hideProgressBar: true,
          });
          setUser(initialUser);
          navigate('/');
        }
      }
    } catch (error) {
      toast.error(error.message, {
        hideProgressBar: true,
      });
    }
  };

  return (
    <div className="signup-container">
      <Row className="signup-row">
        <Col sm="12" md={{ size: 4, offset: 4 }}>
          <div className="signup-box">
            <h2>Sign Up:</h2>
            <FormGroup>
              <Input
                type="text"
                name="name"
                value={user.name}
                onChange={handleChange}
                placeholder="Enter Name"
              />
            </FormGroup>
            <FormGroup>
              <Input
                type="email"
                name="email"
                value={user.email}
                onChange={handleChange}
                placeholder="Enter Email"
              />
            </FormGroup>
            <FormGroup>
              <Input
                type="password"
                name="password"
                value={user.password}
                onChange={handleChange}
                placeholder="Enter Password"
              />
            </FormGroup>
            <Button color="white" onClick={handleSignUp}>
              Sign Up
            </Button>
            <h6>
              Already have an account? <Link to="/login">Login</Link>
            </h6>
          </div>
        </Col>
      </Row>
    </div>
  );
};

export default SignUp;
